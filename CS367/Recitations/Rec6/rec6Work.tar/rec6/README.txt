Recitation 6 CS 367 section 306

Group members:
Joel Adeniji
Joan Garcia-Cruz
Michael Schneider
Rajen Patel
Isaac Kim
